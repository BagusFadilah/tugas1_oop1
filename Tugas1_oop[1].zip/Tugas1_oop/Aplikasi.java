public class Aplikasi{
    public static void main(String[] args) {
        Mahasiswa mhs = new Mahasiswa("18090128", "Nara AAnindya Guna", "4A");
        System.out.println(mhs.info());
        
    }
}